# WhiteShorts Monitoring Starter Kit
(see quickstart inside for steps)
