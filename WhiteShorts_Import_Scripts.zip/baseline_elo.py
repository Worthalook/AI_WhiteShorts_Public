DB_PATH = 'whiteshorts.db'
def update_ratings_after_outcome(home, away, hs, as_):
    pass
